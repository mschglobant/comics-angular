(function () {
  'use strict';

  angular.module('comicsHome', ['ui.bootstrap', 'ngRoute', 'angular.filter']);
}());
