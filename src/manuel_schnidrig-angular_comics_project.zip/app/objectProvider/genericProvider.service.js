/*global angular */
(function () {
  'use strict';

  angular.module("app")
    .factory("genericProvider", ['$filter', '$http', '$q', '$timeout', function ($filter, $http, $q, $timeout) {
      return new ObjectProvider(window.localStorage, $filter('filter'), $http, $q, $timeout);
    }]);

  //////////

  // Config
  var prefix = "comics_";

  // Private
  var loadedObjects = {};

  // Dependecies
  var storage,
    filter,
    $http,
    $q,
    $timeout;

  // Constructor
  var ObjectProvider = function (staticStorage, filterParam, http, q, timeout) {
    if (!staticStorage) {
      staticStorage = window.localStorage;
    }
    storage = staticStorage;
    filter = filterParam;
    $http = http;
    $q = q;
    $timeout = timeout;
  };

  // Private methods
  var init = function (type) {
    var deferred = $q.defer();

    if (storage[prefix + type]) {

      deferred.resolve(storage[prefix + type]);

    } else {

      $http({
        method: 'GET',
        url: '../api/' + type + 's.json'
      }).then(successCallback, errorCallback);

      ///////
      function successCallback(response) {
        storage[prefix + type] = JSON.stringify(response.data);
        deferred.resolve(storage[prefix + type]);
      }

      function errorCallback(response) {
        deferred.reject("Failed to fetch " + type);
      }

    }

    return deferred.promise;
  }

  var getType = function (type) {

    return init(type).then(loadInMemory).then(returnCachedObject);

    ///////
    function loadInMemory() {

      if (!loadedObjects[type]) {
        loadedObjects[type] = JSON.parse(storage[prefix + type]);
      }

      return loadedObjects[type];

    }

    function returnCachedObject() {
      var deferred = $q.defer();

      // Espera ficticia de hasta 2 segundos
      $timeout(function () {
        deferred.resolve(loadedObjects[type])
      }, Math.floor(Math.random() * 2000))

      return deferred.promise;
    }

  };

  // Public methods
  ObjectProvider.prototype = {

    init: init,

    find: function (type, id) {

      return getType(type).then(success);

      function success(objects) {
        if (!objects[id]) {
          throw "No existe el objeto del tipo '" + type + "' con id '" + id + "'";
        }

        return objects[id];
      }

    },

    findById: function (type, ids) {
      var single = false;
      if (!(ids instanceof Array)) {
        ids = [ids];
        single = true;
      }

      var promise = getType(type).then(function (objects) {
        var result = objects.filter(function (elem) {
          return (elem.id) && ids.indexOf(elem.id) !== -1;
        });
        if (single) {
          if (result.length < 1) {
            throw "No existe el objeto del tipo '" + type + "' con id '" + ids + "'";
          }
          return result[0];
        }
        return result;
      });

      return promise;
    },

    findBy: function (type, expr) {

      return getType(type).then(success);

      ///////
      function success(currentCollection) {
        return filter(currentCollection, expr, true);
      }
    },

    findAll: function (type) {
      return getType(type);
    },

    persist: function (type, object) {

      return getType(type).then(success);

      ///////
      function success(currentCollection) {

        if (object.id) {
          var index = findWithAttr(currentCollection, 'id', object.id);
          if (index) {
            currentCollection[index] = object;
          } else {
            currentCollection.push(object);
          }
        } else {
          // Maximo id
          var newId = currentCollection.reduce(function (valorAnterior, valorActual, index, array) {
            return valorActual > valorAnterior ? valorActual : valorAnterior;
          });
          object.id = newId;
          currentCollection.push(object);
        }

        // Flush! (sacar de aca)
        loadedObjects[type] = currentCollection;
        storage[prefix + type] = JSON.stringify(currentCollection);

        // Funcion para buscar elemento del array con una prop determinada
        function findWithAttr(array, attr, value) {
          for (var i = 0; i < array.length; i += 1) {
            if (array[i][attr] === value) {
              return i;
            }
          }
        }
      }

    },

    flush: function (type) {
      getType(type).then(function () {
        loadedObjects[type] = currentCollection;
        storage[prefix + type] = JSON.stringify(currentCollection);
      });
    }
  };

  // Polyfills
  if (!Array.prototype.filter) {
    Array.prototype.filter = function (fun /*, thisArg*/ ) {
      'use strict';

      if (this === void 0 || this === null) {
        throw new TypeError();
      }

      var t = Object(this);
      var len = t.length >>> 0;
      if (typeof fun !== 'function') {
        throw new TypeError();
      }

      var res = [];
      var thisArg = arguments.length >= 2 ? arguments[1] : void 0;
      for (var i = 0; i < len; i++) {
        if (i in t) {
          var val = t[i];

          // NOTE: Technically this should Object.defineProperty at
          //       the next index, as push can be affected by
          //       properties on Object.prototype and Array.prototype.
          //       But that method's new, and collisions should be
          //       rare, so use the more-compatible alternative.
          if (fun.call(thisArg, val, i, t)) {
            res.push(val);
          }
        }
      }

      return res;
    };
  }
  // Production steps of ECMA-262, Edition 5, 15.4.4.14
  // Reference: http://es5.github.io/#x15.4.4.14
  if (!Array.prototype.indexOf) {
    Array.prototype.indexOf = function (searchElement, fromIndex) {

      var k;

      // 1. Let O be the result of calling ToObject passing
      //    the this value as the argument.
      if (this == null) {
        throw new TypeError('"this" is null or not defined');
      }

      var O = Object(this);

      // 2. Let lenValue be the result of calling the Get
      //    internal method of O with the argument "length".
      // 3. Let len be ToUint32(lenValue).
      var len = O.length >>> 0;

      // 4. If len is 0, return -1.
      if (len === 0) {
        return -1;
      }

      // 5. If argument fromIndex was passed let n be
      //    ToInteger(fromIndex); else let n be 0.
      var n = +fromIndex || 0;

      if (Math.abs(n) === Infinity) {
        n = 0;
      }

      // 6. If n >= len, return -1.
      if (n >= len) {
        return -1;
      }

      // 7. If n >= 0, then Let k be n.
      // 8. Else, n<0, Let k be len - abs(n).
      //    If k is less than 0, then let k be 0.
      k = Math.max(n >= 0 ? n : len - Math.abs(n), 0);

      // 9. Repeat, while k < len
      while (k < len) {
        // a. Let Pk be ToString(k).
        //   This is implicit for LHS operands of the in operator
        // b. Let kPresent be the result of calling the
        //    HasProperty internal method of O with argument Pk.
        //   This step can be combined with c
        // c. If kPresent is true, then
        //    i.  Let elementK be the result of calling the Get
        //        internal method of O with the argument ToString(k).
        //   ii.  Let same be the result of applying the
        //        Strict Equality Comparison Algorithm to
        //        searchElement and elementK.
        //  iii.  If same is true, return k.
        if (k in O && O[k] === searchElement) {
          return k;
        }
        k++;
      }
      return -1;
    };
  }

}());
