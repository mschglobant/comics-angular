/*global angular */
(function () {
  'use strict';

  angular.module("app", ['ngRoute', 'ui.bootstrap', 'comicsHome', 'ngStorage']);

}());
